# Creating Custom User Defined Aggregation Functions

[Apache Hive](https://hive.apache.org/) is a SQL-on-Hadoop framework that leverages both MapReduce and Tez to execute queries. It is possible to extend Hive with your own code. Hive has a very flexible API, so you can write code to do a whole bunch of things, unfortunately the flexibility comes at the expense of complexity.

In addition to the built-in functions Hive provides, there are three types of function APIs: UDF, UDTF, and UDAF which all do very different things.

* Normal User Defined Functions (UDF)
    Normal functions take inputs from a single row, and output a single value. Examples of built-in functions include `unix_timestamp`, `round`, and `cos`.

* User Defined Aggregation Function (UDAF)
    Aggregate functions can operate over an entire table at once to perform some sort of aggregation. Examples of built-in aggregate functions include `sum`, `count`, `min`, and `histogram_numeric`.

* User Defined Table Function (UDTF)
    Table functions are similar to UDF functions, but they can output both multiple columns *and* multiple rows of data. Examples of built-in table functions include `explode`, `json_tuple`, and `inline`.

In this lab, we will look at a function type in Hive that allows working with column data - a GenericUDAF represented by `org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver` and `org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator`. Examples of built-in UDAF functions include `sum()` and `count()`.

## Instructions

1. First, copy the `src` directory as well as `people.txt` to a place that you can compile it against your Hadoop and Hive installation. The Java classpath argument will be different depending on where those libraries are located for your system. The simple and complex UDF can be compiled and packaged as follows with the Hortonworks Sandbox:

    ```
    [root@sandbox src]# javac -cp $(hadoop classpath):/usr/hdp/current/hive-client/lib/* com/example/*.java
    [root@sandbox src]# jar -cf customudaf.jar com/
    ```

1. The `people.txt` is a simple list of names that will be used to create a Hive table.

    ```
    John Smith
    John and Ann White
    Ted Green
    Dorothy
    ```

    If you have already created this table as part of `lab-01-custom-udf`, you can skip this step. Otherwise, start Hive and run the following commands to create the `people` table and populate it. The table has one column `name` which contains names of individuals and couples.

    ```
    create table if not exists people (name String);

    load data local inpath 'people.txt' overwrite into table people;
    ```

### A Practical Example

There are cases when we want to process data inside a column, contrary to a row data. Aggregating or ordering the data in a column for example. Lets suppose we want to calculate number of letters in the entire `name` column of our `people` table.

To create a GenericUDAF we have to implement `org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver` and `org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator`.

The resolver simply checks the input parameters and specifies which resolver to use, and so is fairly simple.

```java
public GenericUDAFEvaluator getEvaluator(TypeInfo[] parameters) throws SemanticException;
```

The main work happens inside the Evaluator, in which we have several methods to implement.

```java
// Object inspectors for input and output parameters
public  ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException;

// class to store the result of the data processing
abstract AggregationBuffer getNewAggregationBuffer() throws HiveException;

// reset Aggregation buffer
public void reset(AggregationBuffer agg) throws HiveException;

// process input record
public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException;

// finalize processing of a part of all the input data
public Object terminatePartial(AggregationBuffer agg) throws HiveException;

// add the results of two partial aggregations together
public void merge(AggregationBuffer agg, Object partial) throws HiveException;

// output final result
public Object terminate(AggregationBuffer agg) throws HiveException;
```

The function below calculates the total number of characters in all the strings in the specified column (including spaces)

```java
public static class TotalNumOfLettersEvaluator extends GenericUDAFEvaluator {

    PrimitiveObjectInspector inputOI;
    ObjectInspector outputOI;
    PrimitiveObjectInspector integerOI;

    int total = 0;

    @Override
    public ObjectInspector init(Mode m, ObjectInspector[] parameters)
            throws HiveException {

        assert (parameters.length == 1);
        super.init(m, parameters);

        // init input object inspectors
        if (m == Mode.PARTIAL1 || m == Mode.COMPLETE) {
            inputOI = (PrimitiveObjectInspector) parameters[0];
        } else {
            integerOI = (PrimitiveObjectInspector) parameters[0];
        }

        // init output object inspectors
        // For partial function - array of integers
        outputOI = ObjectInspectorFactory.getReflectionObjectInspector(Integer.class, ObjectInspectorOptions.JAVA);
        return outputOI;

    }

    /**
     * class for storing the current sum of letters
     */
    static class LetterSumAgg implements AggregationBuffer {
        int sum = 0;
        void add(int num){
            sum += num;
        }
    }

    @Override
    public AggregationBuffer getNewAggregationBuffer() throws HiveException {
        LetterSumAgg result = new LetterSumAgg();
        return result;
    }

    @Override
    public void reset(AggregationBuffer agg) throws HiveException {
        LetterSumAgg myagg = new LetterSumAgg();
    }

    private boolean warned = false;

    @Override
    public void iterate(AggregationBuffer agg, Object[] parameters)
            throws HiveException {
        assert (parameters.length == 1);
        if (parameters[0] != null) {
            LetterSumAgg myagg = (LetterSumAgg) agg;
            Object p1 = ((PrimitiveObjectInspector) inputOI).getPrimitiveJavaObject(parameters[0]);
            myagg.add(String.valueOf(p1).length());
        }
    }

    @Override
    public Object terminatePartial(AggregationBuffer agg) throws HiveException {
        LetterSumAgg myagg = (LetterSumAgg) agg;
        total += myagg.sum;
        return total;
    }

    @Override
    public void merge(AggregationBuffer agg, Object partial)
            throws HiveException {
        if (partial != null) {

            LetterSumAgg myagg1 = (LetterSumAgg) agg;

            Integer partialSum = (Integer) integerOI.getPrimitiveJavaObject(partial);

            LetterSumAgg myagg2 = new LetterSumAgg();

            myagg2.add(partialSum);
            myagg1.add(myagg2.sum);
        }
    }

    @Override
    public Object terminate(AggregationBuffer agg) throws HiveException {
        LetterSumAgg myagg = (LetterSumAgg) agg;
        total = myagg.sum;
        return myagg.sum;
    }
}
```

### Code Walkthrough

To understand the API of this function better remember that Hive is just a set of MapReduce functions. The MapReduce code itself has been written for us and is hidden from our view for convenience (or inconvenience, perhaps). So let us refresh ourselves on Mappers and Combiners and Reducers while thinking about this function. Remember that with Hadoop we have different machines, and on each machine Mappers and Reducers work independently of all the others.

So broadly, this function reads data (mapper), combines a bunch of mapper output into partial results (combiner), and finally creates a final, combined output (reducer). Because we aggregate across many combiners, we need to accommodate the idea of partial results.

Looking deeper at the structure of the class:

* `init` - specifies input and output types of data (we have previously seen the requirement to specify input and output parameters)
* `iterate` - reads data from the input table (a typical Mapper)
* `terminate` - outputs the final result (the Reducer)

and then there are Partials and an AggregationBuffer:

* `terminatePartial` - outputs a partial result
* `merge` - merges partial results into a single result (eg the outputs of multiple combiner calls)

The `AggregationBuffer` allows us to store intermediate (and final) results. By defining our own buffer, we can process any type of data we like.

In the code example, a sum of letters is stored in the `AggregationBuffer`.

```java
/**
* class for storing the current sum of letters
*/
static class LetterSumAgg implements AggregationBuffer {
    int sum = 0;
    void add(int num){
      sum += num;
    }
}
```

One final part of the `init` method which may still be confusing is the concept of `Mode`. `Mode` is used to define what the function should be doing at different stages of the MapReduce pipeline (mapping, combining or reducing)

Hive Documentation pages give the following explanation for the Mode:


> Parameters: In PARTIAL1 and COMPLETE mode, the parameters are original data; In PARTIAL2 and FINAL mode, the parameters are just partial aggregations.

> Returns: In PARTIAL1 and PARTIAL2 mode, the `ObjectInspector` for the return value of `terminatePartial()` call; In FINAL and COMPLETE mode, the `ObjectInspector` for the return value of terminate() call.


That means the UDAF receives different input at different MapReduce stages. `iterate` reads a line from our table (or an input record as per the InputFormat of our table to be more precise), and outputs something for aggregation in some other format. `partialAggregation` combines a number of these elements into an aggregated form of the same format. And then the final reducer takes this input and outputs a final result a format of which may be different from format in which the data was received.

In the `init()` function we specify *input* as a string, *final output* as an integer, and partial aggregation output as an integer (stored in an aggregation buffer). That is, `iterate()` gets a String, `merge()` an Integer; and both `terminate()` and `terminatePartial()` output an Integer.

```java
// init input object inspectors depending on the mode
if (m == Mode.PARTIAL1 || m == Mode.COMPLETE) {
    inputOI = (PrimitiveObjectInspector) parameters[0];
} else {
    integerOI = (PrimitiveObjectInspector) parameters[0];
}

// output
outputOI = ObjectInspectorFactory.getReflectionObjectInspector(Integer.class, ObjectInspectorOptions.JAVA);
```

The `iterate()` function gets an input string from the column and calculates and stores the length of the input string.

```java
public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
    ...
    Object p1 = ((PrimitiveObjectInspector) inputOI).getPrimitiveJavaObject(parameters[0]);
    myagg.add(String.valueOf(p1).length());
    }
}
```

Merge adds a result of a partial sum to the AggregationBuffer

```java
public void merge(AggregationBuffer agg, Object partial) throws HiveException {
    if (partial != null) {

        LetterSumAgg myagg1 = (LetterSumAgg) agg;

        Integer partialSum = (Integer) integerOI.getPrimitiveJavaObject(partial);

        LetterSumAgg myagg2 = new LetterSumAgg();

        myagg2.add(partialSum);
        myagg1.add(myagg2.sum);
    }
}
```

Terminate returns the contents of an AggregationBuffer. This is where the final result is produced.

```java
public Object terminate(AggregationBuffer agg) throws HiveException {
    LetterSumAgg myagg = (LetterSumAgg) agg;
    total = myagg.sum;
    return myagg.sum;
}
```

### Using the Function in Hive

Start the `hive` command line client in the same directory as `customudaf.jar` and execute the following commands to see the UDAF in action:

```
add jar customudaf.jar;
create function letters as 'com.example.TotalNumOfLettersGenericUDAF';

select letters(name) from people;
OK
44
Time taken: 8.019 seconds, Fetched: 1 row(s)
```
