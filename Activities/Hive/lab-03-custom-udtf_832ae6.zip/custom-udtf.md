# Creating Custom User Defined Table Functions

[Apache Hive](https://hive.apache.org/) is a SQL-on-Hadoop framework that leverages both MapReduce and Tez to execute queries. It is possible to extend Hive with your own code. Hive has a very flexible API, so you can write code to do a whole bunch of things, unfortunately the flexibility comes at the expense of complexity.

In addition to the built-in functions Hive provides, there are three types of function APIs: UDF, UDTF, and UDAF which all do very different things.

* Normal User Defined Functions (UDF)
    Normal functions take inputs from a single row, and output a single value. Examples of built-in functions include `unix_timestamp`, `round`, and `cos`.

* User Defined Aggregation Function (UDAF)
    Aggregate functions can operate over an entire table at once to perform some sort of aggregation. Examples of built-in aggregate functions include `sum`, `count`, `min`, and `histogram_numeric`.

* User Defined Table Function (UDTF)
    Table functions are similar to UDF functions, but they can output both multiple columns *and* multiple rows of data. Examples of built-in table functions include `explode`, `json_tuple`, and `inline`.

In this lab, we will look at user defined table functions represented by `org.apache.hadoop.hive.ql.udf.generic.GenericUDTF` interface. This function type is more complex, but allows us to output *multiple rows* and *multiple columns* for a single input.

## Instructions

1. First, copy the `src` directory as well as `people.txt` to a place that you can compile it against your Hadoop and Hive installation. The Java classpath argument will be different depending on where those libraries are located for your system. The simple and complex UDF can be compiled and packaged as follows with the Hortonworks Sandbox:

    ```
    [root@sandbox src]# javac -cp $(hadoop classpath):/usr/hdp/current/hive-client/lib/* com/example/*.java
    [root@sandbox src]# jar -cf customudtf.jar com/
    ```


1. The `people.txt` is a simple list of names that will be used to create a Hive table.

    ```
    John Smith
    John and Ann White
    Ted Green
    Dorothy
    ```

    If you have already created this table as part of `lab-01-custom-udf`, you can skip this step. Otherwise, start Hive and run the following commands to create the `people` table and populate it. The table has one column `name` which contains names of individuals and couples.

    ```
    create table if not exists people (name String);

    load data local inpath 'people.txt' overwrite into table people;
    ```

### A Practical Example

The UDF and GenericUDF functions from `lab-01-custom-udf` manipulate a single row of data. They return one element, and they must return a value.

This is not convenient for all data processing tasks. Hive can store data of many kinds and sometimes we do not want to have exactly one row of output for a given input. Perhaps we wish to output a few rows per input row, or output no rows at all. As an example, think what the function `explode` ([a Hive built-In function](https://cwiki.apache.org/confluence/display/Hive/LanguageManual+UDF#LanguageManualUDF-explode)) can do. Similarly, perhaps we also wish to output several columns of data, instead of simply returning a single value. Both these things we can accomplish with a UDTF.

Lets suppose that we would like to create a cleaner table of peoples’ names. The new table will have:

* Separate columns for First Name and Surname.
* No records that do not contain both first and last names (have no separating white space).
* Separate rows for each person in a couple (eg *Nick and Nicole Smith*).

To accomplish this goal, we will implement the `org.apache.hadoop.hive.ql.udf.generic.GenericUDTF` API.

We have to override 3 methods:

```java
// in this method we specify input and output parameters: input ObjectInspector and an output struct
abstract StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException;

// here we process an input record and write out any resulting records
abstract void process(Object[] record) throws HiveException;

// this function is Called to notify the UDTF that there are no more rows to process. Clean up code or additional output can be produced here.
abstract void close() throws HiveException;
```

The implementation of our function is as follows:

```java
public class NameParserGenericUDTF extends GenericUDTF {
    private PrimitiveObjectInspector stringOI = null;

    @Override
    public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
        if (args.length != 1) {
            throw new UDFArgumentException("NameParserGenericUDTF() takes exactly one argument");
        }

        if (args[0].getCategory() != ObjectInspector.Category.PRIMITIVE
            && ((PrimitiveObjectInspector) args[0]).getPrimitiveCategory() != PrimitiveObjectInspector.PrimitiveCategory.STRING) {
            throw new UDFArgumentException("NameParserGenericUDTF() takes a string as a parameter");
        }

        // input
        stringOI = (PrimitiveObjectInspector) args[0];

        // output
        List<String> fieldNames = new ArrayList<String>(2);
        List<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>(2);
        fieldNames.add("name");
        fieldNames.add("surname");
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
    }

    public ArrayList<Object[]> processInputRecord(String name){
        ArrayList<Object[]> result = new ArrayList<Object[]>();

        // ignoring null or empty input
        if (name == null || name.isEmpty()) {
            return result;
        }

        String[] tokens = name.split("\\s+");

        if (tokens.length == 2){
            result.add(new Object[] { tokens[0], tokens[1] });
        } else if (tokens.length == 4 && tokens[1].equals("and")){
            result.add(new Object[] { tokens[0], tokens[3] });
            result.add(new Object[] { tokens[2], tokens[3] });
        }

        return result;
    }

    @Override
    public void process(Object[] record) throws HiveException {
        final String name = stringOI.getPrimitiveJavaObject(record[0]).toString();
        ArrayList<Object[]> results = processInputRecord(name);

        Iterator<Object[]> it = results.iterator();

        while (it.hasNext()){
            Object[] r = it.next();
            forward(r);
        }
    }

    @Override
    public void close() throws HiveException {
        // do nothing
    }
}
```

### Code Walkthrough

The UDTF takes string as a parameter and returns a struct with two fields. Similarly to the `GenericUDF`, we have to manually configure all of the input and output object inspectors Hive needs in order to understand the inputs and outputs.

We identify a `PrimitiveObjectInspector` for the input string.

```java
stringOI = (PrimitiveObjectInspector) args[0];
```

Defining the output object inspectors requires us to define both field names, and the object inspectors required to read each field (in our case, both fields are strings).

```java
List<String> fieldNames = new ArrayList<String>(2);
fieldNames.add("name");
fieldNames.add("surname");

List<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>(2);
fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);

return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
```

The bulk of our logic resides in the `processInputRecord` function which is fairly straightforward. Separating our logic allows easier testing without having to struggle with object inspectors.

Finally, once we have the result we can *forward* it, this registers that object as an output record for Hive to process.

```java
    while (it.hasNext()){
        Object[] r = it.next();
        forward(r);
    }
}
```

### Using the Function in Hive

Start the `hive` command line client in the same directory as `customudtf.jar` and execute the following commands to see the UDTF in action:

```
create function process_names as 'com.example.NameParserGenericUDTF';

select adTable.name, adTable.surname from people lateral view process_names(name) adTable as name, surname;
OK
John  Smith
John  White
Ann   White
Ted   Green
Time taken: 0.171 seconds, Fetched: 4 row(s)
```

You can see that *John and Ann White* now have their own records and *Dorothy* was ignored because there is no surname.
