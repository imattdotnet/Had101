# Hive Partitioning

Hive is excellent for performing queries on large datasets, especially datasets that require full table scans. But quite often there are instances where users need to filter the data on specific column values. Generally, Hive users know about the domain of the data that they deal with. With this knowledge they can identify common columns that are frequently queried in order to identify columns with low cardinality which can be used to organize data using the partitioning feature of Hive. In non-partitioned tables, Hive would have to read all the files in a table’s data directory and subsequently apply filters on it. This is slow and expensive—especially in cases of large tables.

The concept of partitioning is not new for folks who are familiar with relational databases. Partitions are essentially horizontal slices of data which allow larger sets of data to be separated into more manageable chunks. In Hive, partitioning is supported for both managed *and* external tables in the table definition as seen below.

```
CREATE TABLE REGISTRATION DATA   (
    userid             BIGINT,
    First_Name         STRING,
    Last_Name          STRING,
    address1           STRING,
    address2           STRING,
    city               STRING,
    zip_code           STRING,
    state              STRING

)
PARTITION BY  (
    REGION             STRING,
    COUNTRY            STRING
)
```

As you can see, multi-column partition is supported (REGION/COUNTRY). You do not need to include the partition columns in the table definition and you can still use them in your query projections. The partition statement lets Hive alter the way it manages the underlying structures of the table’s data directory. If you browse the location of the data directory for a non-partitioned table, it will look like this: `.db/`. All the data files are directly written to this directory. In case of partitioned tables, subdirectories are created under the table’s data directory for each unique value of a partition column. In case the table is partitioned on multiple columns, then Hive creates nested subdirectories based on the order of partition columns in the table definition.

When a partitioned table is queried with one or both partition columns in criteria or in the `WHERE` clause, what Hive effectively does is partition elimination by scanning only those data directories that are needed. If no partitioned columns are used, then all the directories are scanned (full table scan) and partitioning will not have any effect.

## Pointers

A few things to keep in mind when using partitioning:

* It’s important to consider the cardinality of the column that will be partitioned on. Selecting a column with high cardinality will result in fragmentation of data and put strain on the name node to manage all the underlying structures in HDFS.
* Do not over-partition the data. With too many small partitions, the task of recursively scanning the directories becomes more expensive than a full table scan of the table.
* Partitioning columns should be selected such that it results in roughly similar size partitions in order to prevent a single long running thread from holding up things.
* If `hive.exec.dynamic.partition.mode` is set to `strict`, then you need to do at least one static partition. In non-strict mode, all partitions are allowed to be dynamic. (Dynamic and static partitions will be explained below)
* If your partitioned table is very large, you could block any full table scan queries by putting Hive into strict mode using the `set hive.mapred.mode=strict` command. In this mode, when users submit a query that would result in a full table scan (i.e. queries without any partitioned columns) an error is issued.
* Partitioning is supported for **managed** tables as well as **external** tables.

## External Table

Let's walk through an example using a Hive external table.

### Setup

1. First, add the `employees.txt` data set to HDFS.

    In PayPal:

    ```
    $ hadoop fs -mkdir /user/<user>/employees
    $ hadoop fs -put employees.txt /user/<user>/employees/employees.txt
    ```

    In Hortonworks VM:

    ```
    [hdfs@sandbox ~]$ hadoop fs -mkdir /tmp/employees
    [hdfs@sandbox ~]$ hadoop fs -put /tmp/employees/employees.txt /tmp/employees/employees.txt
    ```

    This data set is a small list of employees with job title, salary, and a department identifier:

    ```
    1,Anne,Admin,50000,A
    2,Gokul,Admin,50000,B
    3,Janet,Sales,60000,A
    4,Hari,Admin,50000,C
    5,Sanker,Admin,50000,C
    6,Margaret,Tech,12000,A
    7,Nirmal,Tech,12000,B
    8,jinju,Engineer,45000,B
    9,Nancy,Admin,50000,A
    10,Andrew,Manager,40000,A
    11,Arun,Manager,40000,B
    12,Harish,Sales,60000,B
    13,Robert,Manager,40000,A
    14,Laura,Engineer,45000,A
    15,Anju,Ceo,100000,B
    16,Aarathi,Manager,40000,B
    17,Parvathy,Engineer,45000,B
    18,Gopika,Admin,50000,B
    19,Steven,Engineer,45000,A
    20,Michael,Ceo,100000,A
    ```

1. Start the `hive` command line interface and create a *non partitioned* external table to store the data (staging table):

    In PayPal:

    ```
    create external table employees_staging
    (EmployeeID Int,
    FirstName String,
    JobTitle String,
    Salary Int,
    Department String)
    row format delimited fields terminated by "," location '/user/<user>/employees';
    ```

    In Hortonworks VM:

    ```
    create external table employees_staging
    (EmployeeID Int,
    FirstName String,
    JobTitle String,
    Salary Int,
    Department String)
    row format delimited fields terminated by "," location '/tmp/employees';
    ```

1. Now create a *partitioned* table:

    ```
    create table employees_partitioned
    (EmployeeID Int,
    FirstName String,
    JobTitle String,
    Salary Int)
    partitioned by (Department String) row format delimited fields terminated by ",";
    ```

### Static and Dynamic Partitions

Data insertion into partitioned tables can be done in two modes:

* Static Partitioning
* Dynamic Partitioning

#### Static Partitioning

Static partitioning requires an individual insert for each partition column. Using our dataset, this would look like:

```
INSERT INTO TABLE employees_partitioned  PARTITION(department='A')
SELECT EmployeeID, FirstName, JobTitle, Salary FROM employees_staging WHERE department='A';

INSERT INTO TABLE employees_partitioned PARTITION (department='B')
SELECT EmployeeID, FirstName, JobTitle, Salary FROM employees_staging WHERE department='B';

INSERT INTO TABLE employees_partitioned PARTITION (department='C')
SELECT EmployeeID, FirstName, JobTitle, Salary FROM employees_staging WHERE department='C';
```


This approach happens to be perfectly reasonable for this particular dataset because there are only 3 partition columns but what about if the number of partitions is large? Perhaps you have a partition column representing each country in the world -- this would add up to a lot of SQL!

#### Dynamic Partitioning

Dynamic partitioning allows for a *single* insert to partition the entire table. Before you can use this feature, there are a couple of options that must be set in the `hive` command line interface:

```
set hive.exec.dynamic.partition=true;
```

This enables dynamic partitions -- by default it is false.

```
set hive.exec.dynamic.partition.mode=nonstrict;
```

You should set this if you are using the dynamic partition without a static partition. A table can be partitioned based on multiple columns in Hive. In strict mode you can use dynamic partitioning only with a static partition too.

It may also be necessary to modify the following setting:

```
hive.exec.max.created.files=100000
```

The default value is 100000 but if you are importing a large data set, it may need to be adjusted.

The Hive command to populate the partitions dynamically is:

```
INSERT OVERWRITE TABLE employees_partitioned PARTITION(department) SELECT EmployeeID, FirstName, JobTitle, Salary, department FROM employees_staging;
```

## Managed Table

Let's walk through another example and this time we will use a managed table.

### Setup

1. This time let's use a non-trival data set. The [Airline On Time dataset](http://stat-computing.org/dataexpo/2009/) consists of flight arrival and departure details for all commercial flights within the USA. We will use the year 2007 for this exercise and a gzipped copy can be found [here](https://drive.google.com/file/d/0B-z1bichbEq-WE5OQjEzdlVqaDQ/view?usp=sharing) which already has the CSV headers removed. There is also a small `1976.csv` file in the lab directory that will be used for adding a partition later. Add them both to HDFS with the following command:

  In PayPal:

  Copy the files `2007.csv.gz` and `1976.csv.gz` from your local drive to bastion, from there to the Hadoop server, and from there to HDFS.

  If you are working in the Hortonworks VM:

    ```
    [hdfs@sandbox ~]# hadoop fs -put /tmp/2007.csv.gz /tmp/2007.csv.gz
    [hdfs@sandbox ~]# hadoop fs -put /tmp/1976.csv.gz /tmp/1976.csv.gz
    ```

1. Start the `hive` command line interface and create a *non partitioned* managed table to store the data (staging table). You may notice that we are loading the file in gzip format. This is one of the cool features of Hive and in some cases is actually more efficient than loading uncompressed data. You can [read more about it here](https://cwiki.apache.org/confluence/display/Hive/CompressedStorage).

    ```
    create table ontime_2007_staging
    (Year INT ,
    Month INT ,
    DayofMonth INT ,
    DayOfWeek INT ,
    DepTime INT ,
    CRSDepTime INT ,
    ArrTime INT ,
    CRSArrTime INT ,
    UniqueCarrier STRING ,
    FlightNum INT ,
    TailNum STRING ,
    ActualElapsedTime INT ,
    CRSElapsedTime INT ,
    AirTime STRING ,
    ArrDelay INT ,
    DepDelay INT ,
    Origin STRING ,
    Dest STRING ,
    Distance INT ,
    TaxiIn STRING ,
    TaxiOut STRING ,
    Cancelled INT ,
    CancellationCode STRING ,
    Diverted INT ,
    CarrierDelay STRING ,
    WeatherDelay STRING ,
    NASDelay STRING ,
    SecurityDelay STRING ,
    LateAircraftDelay STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
    STORED AS TEXTFILE;

    load data inpath '/user/<user>/2007.csv.gz' into table ontime_2007_staging;
    ```

1. Now create a *partitioned* table and this time we will use two columns -- year and month:

    ```
    create table ontime_partitioned
    (DayofMonth INT ,
    DayOfWeek INT ,
    DepTime INT ,
    CRSDepTime INT ,
    ArrTime INT ,
    CRSArrTime INT ,
    UniqueCarrier STRING ,
    FlightNum INT ,
    TailNum STRING ,
    ActualElapsedTime INT ,
    CRSElapsedTime INT ,
    AirTime STRING ,
    ArrDelay INT ,
    DepDelay INT ,
    Origin STRING ,
    Dest STRING ,
    Distance INT ,
    TaxiIn STRING ,
    TaxiOut STRING ,
    Cancelled INT ,
    CancellationCode STRING ,
    Diverted INT ,
    CarrierDelay STRING ,
    WeatherDelay STRING ,
    NASDelay STRING ,
    SecurityDelay STRING ,
    LateAircraftDelay STRING)
    PARTITIONED BY (Year INT, Month INT)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
    STORED AS TEXTFILE;
    ```

1. Let's use dynamic partitioning for this data load instead of writing 12 SQL statements for each month of the year. Before doing so, remember that `hive.exec.dynamic.partition` and `hive.exec.dynamic.partition.mode` should be set as follows:

    ```
    SET hive.exec.dynamic.partition = true;
    SET hive.exec.dynamic.partition.mode = nonstrict;

    INSERT OVERWRITE TABLE ontime_partitioned PARTITION(Year, Month) SELECT DayofMonth, DayOfWeek, DepTime, CRSDepTime, ArrTime, CRSArrTime, UniqueCarrier, FlightNum, TailNum, ActualElapsedTime, CRSElapsedTime, AirTime, ArrDelay, DepDelay, Origin, Dest, Distance, TaxiIn, TaxiOut, Cancelled, CancellationCode, Diverted, CarrierDelay, WeatherDelay, NASDelay, SecurityDelay, LateAircraftDelay, Year, Month FROM ontime_2007_staging;
    ```

    When complete, you should see output similar to the following:

    ```
    Loading data to table default.ontime_partitioned partition (year=null, month=null)
    	 Time taken for load dynamic partitions : 3498
    	Loading partition {year=2007, month=4}
    	Loading partition {year=2007, month=10}
    	Loading partition {year=2007, month=11}
    	Loading partition {year=2007, month=3}
    	Loading partition {year=2007, month=5}
    	Loading partition {year=2007, month=6}
    	Loading partition {year=2007, month=8}
    	Loading partition {year=2007, month=9}
    	Loading partition {year=2007, month=7}
    	Loading partition {year=2007, month=1}
    	Loading partition {year=2007, month=12}
    	Loading partition {year=2007, month=2}
    	 Time taken for adding to write entity : 9
    Partition default.ontime_partitioned{year=2007, month=1} stats: [numFiles=1, numRows=621559, totalSize=54005225, rawDataSize=53383666]
    Partition default.ontime_partitioned{year=2007, month=10} stats: [numFiles=1, numRows=629992, totalSize=54880359, rawDataSize=54250367]
    Partition default.ontime_partitioned{year=2007, month=11} stats: [numFiles=1, numRows=605149, totalSize=52724890, rawDataSize=52119741]
    Partition default.ontime_partitioned{year=2007, month=12} stats: [numFiles=1, numRows=614139, totalSize=53545798, rawDataSize=52931659]
    Partition default.ontime_partitioned{year=2007, month=2} stats: [numFiles=1, numRows=565604, totalSize=49149947, rawDataSize=48584343]
    Partition default.ontime_partitioned{year=2007, month=3} stats: [numFiles=1, numRows=639209, totalSize=55637934, rawDataSize=54998725]
    Partition default.ontime_partitioned{year=2007, month=4} stats: [numFiles=1, numRows=614648, totalSize=53491724, rawDataSize=52877076]
    Partition default.ontime_partitioned{year=2007, month=5} stats: [numFiles=1, numRows=631609, totalSize=54974608, rawDataSize=54342999]
    Partition default.ontime_partitioned{year=2007, month=6} stats: [numFiles=1, numRows=629280, totalSize=54769740, rawDataSize=54140460]
    Partition default.ontime_partitioned{year=2007, month=7} stats: [numFiles=1, numRows=648560, totalSize=56499148, rawDataSize=55850588]
    Partition default.ontime_partitioned{year=2007, month=8} stats: [numFiles=1, numRows=653279, totalSize=56895086, rawDataSize=56241807]
    Partition default.ontime_partitioned{year=2007, month=9} stats: [numFiles=1, numRows=600187, totalSize=52281649, rawDataSize=51681462]
    OK
    Time taken: 62.157 seconds
    ```

1. Try out some queries and compare the performance difference between querying the staging table vs the partitioned table such as:

    ```
    select * from ontime_partitioned where origin == 'LAX' and dest == 'AUS' and month == 3;
    1	4	1047	1045	1509	1530	WN	1693	N396SW	142	165	128	-21	2	LAX	AUS	1242	3	11	0      		0	0	0	0	0	0	2007	3
    2	5	1130	1045	1551	1530	WN	1693	N391SW	141	165	130	21	45	LAX	AUS	1242	4	70	       	0	0	0	1	0	20	2007	3
    3	6	1057	1045	1523	1530	WN	1693	N607SW	146	165	133	-7	12	LAX	AUS	1242	4	90	       	0	0	0	0	0	0	2007	3
    4	7	1133	1045	1623	1530	WN	1693	N611SW	170	165	160	53	48	LAX	AUS	1242	3	70	       	0	0	0	5	0	48	2007	3
    ...
    ```

## Partition Information

The `show partitions <table>` and `describe extended <table>` commands are useful to see partition information for a given table:

```
show partitions employees_partitioned;
OK
department=A
department=B
department=C
Time taken: 0.623 seconds, Fetched: 3 row(s)

describe extended employees_partitioned;
OK
employeeid          	int
firstname           	string
jobtitle            	string
salary              	int
department          	string

# Partition Information
# col_name            	data_type           	comment

department          	string

Detailed Table Information	Table(tableName:employees_partitioned, dbName:default, owner:hdfs, createTime:1490324753, lastAccessTime:0, retention:0, sd:StorageDescriptor(cols:[FieldSchema(name:employeeid, type:int, comment:null), FieldSchema(name:firstname, type:string, comment:null), FieldSchema(name:jobtitle, type:string, comment:null), FieldSchema(name:salary, type:int, comment:null), FieldSchema(name:department, type:string, comment:null)], location:hdfs://sandbox.hortonworks.com:8020/apps/hive/warehouse/employees_partitioned, inputFormat:org.apache.hadoop.mapred.TextInputFormat, outputFormat:org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat, compressed:false, numBuckets:-1, serdeInfo:SerDeInfo(name:null, serializationLib:org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe, parameters:{serialization.format=,, field.delim=,}), bucketCols:[], sortCols:[], parameters:{}, skewedInfo:SkewedInfo(skewedColNames:[], skewedColValues:[], skewedColValueLocationMaps:{}), storedAsSubDirectories:false), partitionKeys:[FieldSchema(name:department, type:string, comment:null)], parameters:{transient_lastDdlTime=1490324753}, viewOriginalText:null, viewExpandedText:null, tableType:MANAGED_TABLE)
Time taken: 0.536 seconds, Fetched: 12 row(s)
```

You can also limit the `describe` output to one partition:

In PayPal:

```
hive> describe formatted ontime_partitioned partition(year=2007, month=2);
OK
# col_name            	data_type           	comment

dayofmonth          	int
dayofweek           	int
deptime             	int
crsdeptime          	int
arrtime             	int
crsarrtime          	int
uniquecarrier       	string
flightnum           	int
tailnum             	string
actualelapsedtime   	int
crselapsedtime      	int
airtime             	string
arrdelay            	int
depdelay            	int
origin              	string
dest                	string
distance            	int
taxiin              	string
taxiout             	string
cancelled           	int
cancellationcode    	string
diverted            	int
carrierdelay        	string
weatherdelay        	string
nasdelay            	string
securitydelay       	string
lateaircraftdelay   	string

# Partition Information
# col_name            	data_type           	comment

year                	int
month               	int

# Detailed Partition Information
Partition Value:    	[2007, 2]
Database:           	default
Table:              	ontime_partitioned
CreateTime:         	Sun Apr 16 16:50:52 PDT 2017
LastAccessTime:     	UNKNOWN
Protect Mode:       	None
Location:           	hdfs://horton/user/hive/warehouse/ontime_partitioned/year=2007/month=2
Partition Parameters:
	COLUMN_STATS_ACCURATE	{\"BASIC_STATS\":\"true\"}
	numFiles            	1
	numRows             	565604
	rawDataSize         	48584343
	totalSize           	13940949
	transient_lastDdlTime	1492386655

# Storage Information
SerDe Library:      	org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe
InputFormat:        	org.apache.hadoop.mapred.TextInputFormat
OutputFormat:       	org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat
Compressed:         	No
Num Buckets:        	-1
Bucket Columns:     	[]
Sort Columns:       	[]
Storage Desc Params:
	field.delim         	,
	serialization.format	,
Time taken: 0.178 seconds, Fetched: 63 row(s)
```

> Notice the location of the partition: `hdfs://horton/user/hive/warehouse/ontime_partitioned/year=2007/month=2`.

In Hortonworks VM:

```
describe formatted ontime_partitioned partition(year=2007, month=2);
# col_name            	data_type           	comment

dayofmonth          	int
dayofweek           	int
deptime             	int
crsdeptime          	int
arrtime             	int
crsarrtime          	int
uniquecarrier       	string
flightnum           	int
tailnum             	string
actualelapsedtime   	int
crselapsedtime      	int
airtime             	string
arrdelay            	int
depdelay            	int
origin              	string
dest                	string
distance            	int
taxiin              	string
taxiout             	string
cancelled           	int
cancellationcode    	string
diverted            	int
carrierdelay        	string
weatherdelay        	string
nasdelay            	string
securitydelay       	string
lateaircraftdelay   	string

# Partition Information
# col_name            	data_type           	comment

year                	int
month               	int

# Detailed Partition Information
Partition Value:    	[2007, 2]
Database:           	default
Table:              	ontime_partitioned
CreateTime:         	Fri Mar 24 06:02:29 UTC 2017
LastAccessTime:     	UNKNOWN
Protect Mode:       	None
Location:           	hdfs://sandbox.hortonworks.com:8020/apps/hive/warehouse/ontime_partitioned/year=2007/month=2
Partition Parameters:
	COLUMN_STATS_ACCURATE	{\"BASIC_STATS\":\"true\"}
	numFiles            	1
	numRows             	565604
	rawDataSize         	48584343
	totalSize           	49149947
	transient_lastDdlTime	1490335351

# Storage Information
SerDe Library:      	org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe
InputFormat:        	org.apache.hadoop.mapred.TextInputFormat
OutputFormat:       	org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat
Compressed:         	No
Num Buckets:        	-1
Bucket Columns:     	[]
Sort Columns:       	[]
Storage Desc Params:
	field.delim         	,
	serialization.format	,
Time taken: 1.145 seconds, Fetched: 63 row(s)
```

## Altering Partitions

Hive supports the ability to add, change HDFS location, and drop partitions.

### Adding Partitions

There is a small set of sample airline data in `1976.csv`. Suppose we have just received data for the month of January in 1976 and we need to add a new partition. Use the following commands to add the partition and load the data:

The location will be different depending where are you running the Hive.

In PayPal:

```
alter table ontime_partitioned add if not exists partition (year=1976, month=1) location '/apps/hive/warehouse/ontime_partitioned/year=1976/month=1';

load data inpath '/user/<user>/1976.csv' into table ontime_partitioned partition (year=1976, month=1);

select * from ontime_partitioned where year = 1976;
1976	1	3	4	1422	1255	1657	1610	WN	188	NULL	155	195	143	47	87	NULL	FLL	1093	6	60		0	40	0	0	1976	1
1976	1	3	4	1954	1925	2239	2235	WN	1754	NULL	165	190	155	4	29	NULL	FLL	1093	3	70		0	NA	NA	NA	1976	1
...
```

In Hortonworks VM:

```
alter table ontime_partitioned add if not exists partition (year=1976, month=1) location 'hdfs://horton/user/hive/warehouse/ontime_partitioned/year=1976/month=1';

load data inpath '/tmp/1976.csv' into table ontime_partitioned partition (year=1976, month=1);

select * from ontime_partitioned where year = 1976;
1976	1	3	4	1422	1255	1657	1610	WN	188	NULL	155	195	143	47	87	NULL	FLL	1093	6	60		0	40	0	0	1976	1
1976	1	3	4	1954	1925	2239	2235	WN	1754	NULL	165	190	155	4	29	NULL	FLL	1093	3	70		0	NA	NA	NA	1976	1
...
```



### Changing Partition Location

You can change the partition location in HDFS if needed with a command such as the following:

```
alter table ontime_partitioned partition(year=1976, month=1) set location 'hdfs://sandbox.hortonworks.com:8020/apps/hive/warehouse/somewhere_else';
```

### Dropping Partitions

To drop a partition, use the following command:

```
alter table ontime_partitioned drop if exists partition(year=1976, month=1);
```

## Bucketing

As a final note, let's discuss *bucketing* in Hive.

Much like partitioning, bucketing is a technique that allows you to cluster or segment large sets of data to optimize query performance. To better understand how partitioning and bucketing works, let's say you have a table:

```
CREATE TABLE mytable (
         name string,
         city string,
         employee_id int )
PARTITIONED BY (year STRING, month STRING, day STRING)
CLUSTERED BY (employee_id) INTO 256 BUCKETS
```

You insert some data into a partition for 2015-12-02. Hive will then store data in a directory hierarchy, such as:

```
/user/hive/warehouse/mytable/y=2015/m=12/d=02
```

As such, it is important to be careful when partitioning. As a general rule of thumb, when choosing a field for partitioning, the field should not have a high cardinality - the term *cardinality* refers to the number of possible values a field can have. For instance, if you have a `country` field, the countries in the world are about 300, so cardinality would be ~300. For a field like `timestamp_ms`, which changes every millisecond, cardinality can be billions. The cardinality of the field relates to the number of directories that could be created on the file system. As an example, if you partition by `employee_id` and you have millions of employees, you may end up having millions of directories in your file system.

Bucketing, on the other hand, will result in a fixed number of files, since you specify the number of buckets. What Hive will do is to take the field, calculate a hash and assign a record to that bucket.

Bucketing works well when the field has *high cardinality* and data is **evenly distributed** among buckets. Partitioning works best when the cardinality of the partitioning field is **not too high**.

Also, you can *partition on multiple fields*, with an order (year/month/day is a good example), while you can *bucket on only one field*.

## Conclusion

Partitioning is a useful tool for distributing execution load horizontally in Hive. Query response time is faster when processing a smaller slice of data rather than the entire table.
