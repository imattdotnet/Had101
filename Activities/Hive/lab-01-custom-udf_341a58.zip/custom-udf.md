# Creating Custom User Defined Functions

[Apache Hive](https://hive.apache.org/) is a SQL-on-Hadoop framework that leverages both MapReduce and Tez to execute queries. It is possible to extend Hive with your own code. Hive has a very flexible API, so you can write code to do a whole bunch of things, unfortunately the flexibility comes at the expense of complexity.

In addition to the built-in functions Hive provides, there are three types of function APIs: UDF, UDTF, and UDAF which all do very different things.

* Normal User Defined Functions (UDF)
    Normal functions take inputs from a single row, and output a single value. Examples of built-in functions include `unix_timestamp`, `round`, and `cos`.

* User Defined Aggregation Function (UDAF)
    Aggregate functions can operate over an entire table at once to perform some sort of aggregation. Examples of built-in aggregate functions include `sum`, `count`, `min`, and `histogram_numeric`.

* User Defined Table Function (UDTF)
    Table functions are similar to UDF functions, but they can output both multiple columns *and* multiple rows of data. Examples of built-in table functions include `explode`, `json_tuple`, and `inline`.

In this lab, we will be examining the two different types of normal UDFs.

## Instructions

There are two different interfaces you can use for writing UDFs for Apache Hive which can be categorized as simple and complex.

The simple API (`org.apache.hadoop.hive.ql.exec.UDF`) can be used so long as your function reads and returns Hadoop & Hive writable types such as `Text`, `IntWritable`, `LongWritable`, `DoubleWritable`, etc.

However, if you plan on writing a UDF that can manipulate embedded data structures, such as `Map`, `List`, and `Set`, then you should use `org.apache.hadoop.hive.ql.udf.generic.GenericUDF`, which is a little more involved.

`GenericUDF`s are superior to normal UDFs in the following ways:

1. They can accept arguments of complex types, and return complex types.
1. They can accept variable length of arguments.
1. They can accept an infinite number of function signature
1. They can do short-circuit evaluations using `DeferedObject`.

### Simple UDF

1. First, copy the `src` directory as well as `people.txt` to a place that you can compile it against your Hadoop and Hive installation. The Java classpath argument will be different depending on where those libraries are located for your system. The simple and complex UDF can be compiled and packaged as follows with the Hortonworks Sandbox:

    ```
    [root@sandbox src]# javac -cp $(hadoop classpath):/usr/hdp/current/hive-client/lib/* com/example/*.java
    [root@sandbox src]# jar -cf customudf.jar com/
    ```


1. The `people.txt` is a simple list of names that will be used to create a Hive table.

    ```
    John Smith
    John and Ann White
    Ted Green
    Dorothy
    ```

    Start Hive and run the following commands to create the `people` table and populate it. The table has one column `name` which contains names of individuals and couples.

    ```
    create table if not exists people (name String);

    load data local inpath 'people.txt' overwrite into table people;
    ```

1. The simple UDF we will be running simply reverses the string input that is given to it.

    ```java
    package com.example;

    import org.apache.hadoop.hive.ql.exec.UDF;
    import org.apache.hadoop.io.Text;

    public class ReverseString extends UDF {
        public Text evaluate(final Text text) {
            // return NULL if value of input is NULL.
            if (text == null) {
                return null;
            }
            // Convert Hadoop Text object to StringBuilder
            StringBuilder stringBuilder = new StringBuilder(text.toString());
            // Derive reverse of string using inbuilt api of StringBuilder
            String reverse = stringBuilder.reverse().toString();
            // Convert String to Hadoop Text object and return that.
            return new Text(reverse);
        }
    }
    ```

    The following instructions assume that the `customudf.jar` file is in the same directory in which you are executing Hive. Run the following commands to register the library and create a function in Hive:

    ```
    add jar customudf.jar;

    create function string_reverse as 'com.example.ReverseString';
    ```

1. Now run the function which invokes the UDF as follows:

    ```
    select string_reverse(name) from people;
    htimS nhoJ
    etihW nnA dna nhoJ
    neerG deT
    yhtoroD
    ```

### Complex UDF

The `org.apache.hadoop.hive.ql.udf.generic.GenericUDF` API provides a way to write code for objects that are not writable types, for example - `struct`, `map` and `array` types.

This api requires you to manually manage object inspectors for the function arguments, and verify the number and types of the arguments you receive. An object inspector provides a consistent interface for underlying object types so that different object implementations can all be accessed in a consistent way from within hive (eg you could implement a struct as a `Map` so long as you provide a corresponding object inspector.

The API requires you to implement three methods:

```java
// this is like the evaluate method of the simple API. It takes the actual arguments and returns the result
abstract Object evaluate(GenericUDF.DeferredObject[] arguments);

// Doesn't really matter, we can return anything, but should be a string representation of the function.
abstract String getDisplayString(String[] children);

// called once, before any evaluate() calls. You receive an array of object inspectors that represent the arguments of the function
// this is where you validate that the function is receiving the correct argument types, and the correct number of arguments.
abstract ObjectInspector initialize(ObjectInspector[] arguments);
```

The example that we will be running will illustrate a function called `contains_string` that takes two arguments:
* A list of Strings
* A String

and returns true/false on whether the list contains the string that is provided. For example (in Pseudo Code):

```
contains_string(List("a", "b", "c"), "b"); // true

contains_string(List("a", "b", "c"), "d"); // false
```

Since there are more methods to implement, the `GenericUDF` requires more boilerplate code to set up:

```java
package com.example;

import java.util.List;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.Text;

public class ComplexUDFExample extends GenericUDF {

    ListObjectInspector listOI;
    StringObjectInspector elementOI;


    @Override
    public Object evaluate(DeferredObject[] arguments) throws HiveException {
        // get the list and string from the deferred objects using the object inspectors
        List<Text> list = (List<Text>) this.listOI.getList(arguments[0].get());
        String arg = elementOI.getPrimitiveJavaObject(arguments[1].get());

        // check for nulls
        if (list == null || arg == null) {
            return null;
        }

        // see if our list contains the value we need
        for(Text s: list) {
            if (arg.equals(s.toString())) return new Boolean(true);
        }

        return new Boolean(false);
    }

    @Override
    public String getDisplayString(String[] arg0) {
        return "arrayContainsExample()";
    }

    @Override
    public ObjectInspector initialize(ObjectInspector[] arguments) throws UDFArgumentException {
        if (arguments.length != 2) {
            throw new UDFArgumentLengthException("arrayContainsExample only takes 2 arguments: List<T>, T");
        }

        ObjectInspector a = arguments[0];
        ObjectInspector b = arguments[1];

        if (!(a instanceof ListObjectInspector) || !(b instanceof StringObjectInspector)) {
            throw new UDFArgumentException("first argument must be a list / array, second argument must be a string");
        }

        this.listOI = (ListObjectInspector) a;
        this.elementOI = (StringObjectInspector) b;

        if(!(listOI.getListElementObjectInspector() instanceof StringObjectInspector)){
            throw new UDFArgumentException("first argument must be a list of strings");
        }

        // the return type of our function is a boolean, so we provide the correct object inspector
        return PrimitiveObjectInspectorFactory.javaBooleanObjectInspector;
    }

}
```

The call pattern for a UDF is the following:

1. The UDF is initialized using a default constructor.
1. `udf.initialize()` is called with the array of object instructors for the udf arguments (`ListObjectInspector`, `StringObjectInspector`).
    * We check that we have the right number of arguments (2), and that they are the right types (as above).
    * We store the object instructors for use in `evaluate()` (`listOI`, `elementOI`).
    * We return an object inspector so Hive can read the result of the function (`BooleanObjectInspector`).
1. Evaluate is called for each row in your query with the arguments provided (eg `evaluate(List(“a”, “b”, “c”), “c”)`).
    * We extract the values using the stored object instructors.
    * We do our magic and return a value that aligns with the object inspector returned from initialize. (`list.contains(elemement) ? true : false`)

### Running the Complex UDF

1. You already compiled the complex UDF and packaged it in the same library -- `customudf.jar`. If you have exited the Hive command line interface, it will be necessary to re-register the library but otherwise that step can be skipped:

    ```
    add jar customudf.jar;

    create function contains_string as 'com.example.ComplexUDFExample';

    select contains_string(a.col1, a.col2) from (select array("a", "b", "c") as col1, "d" as col2) a;
    false

    select contains_string(a.col1, a.col2) from (select array("a", "b", "c") as col1, "a" as col2) a;
    true
    ```


## Conclusion

Hopefully this has given you some ideas on how Hive UDFs can be customized for your own needs. Other labs will examine extending UDAFs and UDTFs.
