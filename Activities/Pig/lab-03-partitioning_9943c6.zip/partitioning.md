# Using Partitions with Pig


HCatalog is a table and storage management layer for Hadoop that enables users with different data processing tools — Pig, Hive, MapReduce, and others — to more easily read and write data. HCatalog is part of the [Apache Hive](https://hive.apache.org/) project. The `HCatLoader` and `HCatStorer` interfaces are used with Pig scripts to read and write data in HCatalog-managed tables.

For this exercise, we will be using the [Airline On Time dataset](http://stat-computing.org/dataexpo/2009/) from 2008. A gzipped copy of this dataset can be found [here](https://drive.google.com/drive/folders/0B-z1bichbEq-TUU1TGFYc3dnV1U?usp=sharing) which already has the CSV headers removed. Additionally a very small `2009.csv` has been created in the lab directory with just a few lines modifying the year to 2009.

Before Pig can read and write to the partitioned HCatalog table, we must create it first in Hive. Each table can have one or more partition Keys which determines how the data is stored. Partitions, apart from being storage units, also allow the user to efficiently identify the rows that satisfy a specified criteria; for example, a `date_partition` of type `STRING` and `country_partition` of type `STRING`. Each unique value of the partition keys defines a partition of the table. For example, all "US" data from "2009-12-23" is a partition of the `page_views` table. Therefore, if you run analysis on only the "US" data for 2009-12-23, you can run that query only on the relevant partition of the table, thereby speeding up the analysis significantly. Note however, that just because a partition is named 2009-12-23 does not mean that it contains all or only data from that date; partitions are named after dates for convenience; it is the user's job to guarantee the relationship between partition name and data content! Partition columns are virtual columns, they are not part of the data itself but are derived on load.

## Instructions

1. First, add the data set to HDFS.

    In PayPal, copy the files to bastion, then to the Hadoop server, then to the HDFS.

    If working in the Hortonworks VM, use this:
    ```
    [hdfs@sandbox ~]# hadoop fs -put /tmp/2008.csv.gz /tmp/2008.csv.gz
    [hdfs@sandbox ~]# hadoop fs -put /tmp/2009.csv /tmp/2009.csv
    ```

1. Use the `hive` command line interface or UI to load the data set to a *non-partitioned* table. You may notice that we are loading the file in gzip format. This is one of the cool features of Hive and in some cases is actually more efficient than loading uncompressed data. You can [read more about it here](https://cwiki.apache.org/confluence/display/Hive/CompressedStorage).

    ```
    create table ontime_txt
    (Year INT ,
    Month INT ,
    DayofMonth INT ,
    DayOfWeek INT ,
    DepTime INT ,
    CRSDepTime INT ,
    ArrTime INT ,
    CRSArrTime INT ,
    UniqueCarrier STRING ,
    FlightNum INT ,
    TailNum STRING ,
    ActualElapsedTime INT ,
    CRSElapsedTime INT ,
    AirTime STRING ,
    ArrDelay INT ,
    DepDelay INT ,
    Origin STRING ,
    Dest STRING ,
    Distance INT ,
    TaxiIn STRING ,
    TaxiOut STRING ,
    Cancelled INT ,
    CancellationCode STRING ,
    Diverted INT ,
    CarrierDelay STRING ,
    WeatherDelay STRING ,
    NASDelay STRING ,
    SecurityDelay STRING ,
    LateAircraftDelay STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
    STORED AS TEXTFILE;

    load data inpath '/user/<user>/2008.csv.gz' into table ontime_txt;
    ```

1. We shall now create a *partitioned* table by year and month columns:

    ```
    create table ontime_part
    (DayofMonth INT ,
    DayOfWeek INT ,
    DepTime INT ,
    CRSDepTime INT ,
    ArrTime INT ,
    CRSArrTime INT ,
    UniqueCarrier STRING ,
    FlightNum INT ,
    TailNum STRING ,
    ActualElapsedTime INT ,
    CRSElapsedTime INT ,
    AirTime STRING ,
    ArrDelay INT ,
    DepDelay INT ,
    Origin STRING ,
    Dest STRING ,
    Distance INT ,
    TaxiIn STRING ,
    TaxiOut STRING ,
    Cancelled INT ,
    CancellationCode STRING ,
    Diverted INT ,
    CarrierDelay STRING ,
    WeatherDelay STRING ,
    NASDelay STRING ,
    SecurityDelay STRING ,
    LateAircraftDelay STRING)
    PARTITIONED BY (Year INT, Month INT)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
    STORED AS TEXTFILE;
    ```

1. Before completing the load, a couple of Hive default settings need to be toggled to enable dynamic partitioning.

    ```
    SET hive.exec.dynamic.partition = true;
    SET hive.exec.dynamic.partition.mode = nonstrict;

    INSERT OVERWRITE TABLE ontime_part PARTITION(Year, Month) SELECT DayofMonth, DayOfWeek, DepTime, CRSDepTime, ArrTime, CRSArrTime, UniqueCarrier, FlightNum, TailNum, ActualElapsedTime, CRSElapsedTime, AirTime, ArrDelay, DepDelay, Origin, Dest, Distance, TaxiIn, TaxiOut, Cancelled, CancellationCode, Diverted, CarrierDelay, WeatherDelay, NASDelay, SecurityDelay, LateAircraftDelay, Year, Month FROM ontime_txt;
    ```

    When the load is complete, you should see output similar to the following indicating that the partitions have been created:

    ```
    Loading data to table default.ontime_part partition (year=null, month=null)
    	 Time taken for load dynamic partitions : 3463
    	Loading partition {year=2008, month=4}
    	Loading partition {year=2008, month=11}
    	Loading partition {year=2008, month=12}
    	Loading partition {year=2008, month=7}
    	Loading partition {year=2008, month=1}
    	Loading partition {year=2008, month=10}
    	Loading partition {year=2008, month=2}
    	Loading partition {year=2008, month=9}
    	Loading partition {year=2008, month=3}
    	Loading partition {year=2008, month=8}
    	Loading partition {year=2008, month=5}
    	Loading partition {year=2008, month=6}
    	 Time taken for adding to write entity : 3
    Partition default.ontime_part{year=2008, month=1} stats: [numFiles=1, numRows=605765, totalSize=8695012, rawDataSize=708382542]
    Partition default.ontime_part{year=2008, month=10} stats: [numFiles=1, numRows=556205, totalSize=6884335, rawDataSize=650688842]
    Partition default.ontime_part{year=2008, month=11} stats: [numFiles=1, numRows=523272, totalSize=6915894, rawDataSize=612133608]
    Partition default.ontime_part{year=2008, month=12} stats: [numFiles=1, numRows=544958, totalSize=7837738, rawDataSize=637228588]
    Partition default.ontime_part{year=2008, month=2} stats: [numFiles=1, numRows=569236, totalSize=8296772, rawDataSize=665573272]
    Partition default.ontime_part{year=2008, month=3} stats: [numFiles=1, numRows=616090, totalSize=8561094, rawDataSize=720482464]
    Partition default.ontime_part{year=2008, month=4} stats: [numFiles=1, numRows=598126, totalSize=8376831, rawDataSize=699587296]
    Partition default.ontime_part{year=2008, month=5} stats: [numFiles=1, numRows=606293, totalSize=8356512, rawDataSize=709227774]
    Partition default.ontime_part{year=2008, month=6} stats: [numFiles=1, numRows=608665, totalSize=8728898, rawDataSize=711891766]
    Partition default.ontime_part{year=2008, month=7} stats: [numFiles=1, numRows=627931, totalSize=8817005, rawDataSize=734444002]
    Partition default.ontime_part{year=2008, month=8} stats: [numFiles=1, numRows=612279, totalSize=8549274, rawDataSize=716148990]
    Partition default.ontime_part{year=2008, month=9} stats: [numFiles=1, numRows=540908, totalSize=7188414, rawDataSize=632655084]
    ```


1. Now that the partitioned table has been created, let's access it using Pig. To bring in the appropriate jars for working with HCatalog, include the following flag when running Pig from the shell, Hue, or other applications:

    ```
    pig -useHCatalog
    ```

1.  HCatLoader is used with Pig scripts to read data from HCatalog-managed tables. The syntax is as follows using Pig 0.14+:

    ```
    A = LOAD 'tablename' USING org.apache.hive.hcatalog.pig.HCatLoader();
    ```

    **NOTE:** The fully qualified package name changed from `org.apache.hcatalog.pig` to `org.apache.hive.hcatalog.pig` in Pig versions 0.14+. In many older web site examples you may find references to the old syntax which no longer functions.

    | Previous Pig Versions | 0.14+ |
    | --------------------- | ----- |
    | org.apache.hcatalog.pig.HCatLoader | org.apache.hive.hcatalog.pig.HCatLoader |
    | org.apache.hcatalog.pig.HCatStorer | org.apache.hive.hcatalog.pig.HCatStorer |

    Load our airline data with the following command:

    ```pig
    ontime_part = load 'ontime_part' using org.apache.hive.hcatalog.pig.HCatLoader();
    ```

1. The previous load statement will load all partitions of the specified table. If only some partitions of the specified table are needed, include a partition filter statement immediately following the load statement in the data flow. The filter statement can include conditions on partition as well as non-partition columns.

    Run the following command to filter by a specific month which is one of our partition columns:

    ```pig
    march = filter ontime_part by month == 3;
    ```

1. Pig will push the month filter to HCatalog, so that HCatalog knows to just scan the partition where month = 3. You can combine this filter with others. A filter can contain the operators 'and', 'or', '()', '==', '!=', '<', '>', '<=' and '>='. Run the following command to see the flights that flew from Los Angeles to Austin in the month of March:

    ```pig
    march_lax_to_aus = filter ontime_part by month == 3 and origin == 'LAX' and dest == 'AUS';
    dump march_lax_to_aus;

    ...
    (3,1,945,945,1426,1435,WN,1110,N368SW,161,170,149,-9,0,LAX,AUS,1242,5,7,0,,0,NA,NA,NA,NA,NA,2008,3)
    (4,2,941,945,1420,1435,WN,1110,N632SW,159,170,146,-15,-4,LAX,AUS,1242,4,9,0,,0,NA,NA,NA,NA,NA,2008,3)
    (5,3,947,945,1424,1435,WN,1110,N682SW,157,170,146,-11,2,LAX,AUS,1242,4,7,0,,0,NA,NA,NA,NA,NA,2008,3)
    (6,4,1008,945,1447,1435,WN,1110,N799SW,159,170,146,12,23,LAX,AUS,1242,5,8,0,,0,NA,NA,NA,NA,NA,2008,3)
    (7,5,952,945,1448,1435,WN,1110,N630WN,176,170,165,13,7,LAX,AUS,1242,3,8,0,,0,NA,NA,NA,NA,NA,2008,3)
    (8,6,842,840,1330,1330,WN,2148,N654SW,168,170,149,0,2,LAX,AUS,1242,4,15,0,,0,NA,NA,NA,NA,NA,2008,3)
    ...
    ```

1. HCatStorer is used with Pig scripts to write data to HCatalog-managed tables. Example:

    ```pig
    A = LOAD ...
    B = FOREACH A ...
    ...
    ...
    my_processed_data = ...

    STORE my_processed_data INTO 'tablename'
       USING org.apache.hive.hcatalog.pig.HCatStorer();
    ```

    For the USING clause, you can have a string argument that represents key/value pairs for partition. This is a mandatory argument when you are writing to a partitioned table and the partition column is not in the output column. The values for partition keys should *NOT* be quoted.

    If partition columns are present in data they need not be specified as a STORE argument. Instead HCatalog will use these values to place records in the appropriate partition(s). It is valid to specify some partition keys in the STORE statement and have other partition keys in the data.

    One key point to remember: Partitions contain records. *Once a partition is created records cannot be added to it, removed from it, or updated in it.* Partitions are multi-dimensional and not hierarchical. Records are divided into columns. Columns have a name and a datatype. HCatalog supports the same datatypes as Hive.

    To add one new partition to a partitioned table, specify the partition value in the store function. Pay careful attention to the quoting, as the whole string must be single quoted and separated with an equals sign. In this example, we will create a new partition with the month of 2009 and year of 1:

    ```pig
    flights_2009 = LOAD '/user/<user>/2009.csv' USING org.apache.pig.piggybank.storage.CSVExcelStorage(',', 'YES_MULTILINE', 'NOCHANGE') AS (year:int,
    month:int,
    dayofmonth:int ,
    dayofweek:int ,
    deptime:int ,
    crsdeptime:int,
    arrtime:int ,
    crsarrtime:int ,
    uniquecarrier:chararray ,
    flightnum:int ,
    tailnum:chararray ,
    actualelapsedtime:int ,
    crselapsedtime:int,
    airtime:chararray ,
    arrdelay:int ,
    depdelay:int ,
    origin:chararray ,
    dest:chararray ,
    distance:int ,
    taxiin:chararray ,
    taxiout:chararray ,
    cancelled:int ,
    cancellationcode:chararray ,
    diverted:int ,
    carrierdelay:chararray ,
    weatherdelay:chararray ,
    nasdelay:chararray ,
    securitydelay:chararray ,
    lateaircraftdelay:chararray);

    store flights_2009 into 'ontime_part' using org.apache.hive.hcatalog.pig.HCatStorer('year=2009, month=1');
    ```

    Note that if you wanted to write into multiple partitions at once, make sure that the partition column is present in your data, then call HCatStorer with no argument. As an example:

    ```pig
    store z into 'web_data' using org.apache.hive.hcatalog.pig.HCatStorer();
      -- datestamp must be a field in the relation z
    ```

1. If you switch back over to the Hive CLI, you can now see that the new partition has been created:

    ```
    hive> show partitions ontime_part;
    OK
    year=2008/month=1
    year=2008/month=10
    year=2008/month=11
    year=2008/month=12
    year=2008/month=2
    year=2008/month=3
    year=2008/month=4
    year=2008/month=5
    year=2008/month=6
    year=2008/month=7
    year=2008/month=8
    year=2008/month=9
    year=2009/month=1
    Time taken: 0.629 seconds, Fetched: 13 row(s)
    ```

## Conclusion

As your data gets large, partitioning is key to managing it in a way that it can be efficiently processed in Pig and Hive. By loading only the partitions that you are interested in, Pig processing will be much faster and effective.
