# Extract, Transform, Load (ETL) With Pig

## Introduction

Pig is a high level scripting language that is used with Apache Hadoop. Pig excels at describing data analysis problems as data flows. Pig is complete in that you can do all the required data manipulations in Apache Hadoop with Pig. In addition through the User Defined Functions (UDF) facility in Pig, you can have Pig invoke code in many languages like JRuby, Jython and Java. Conversely you can execute Pig scripts in other languages. The result is that you can use Pig as a component to build larger and more complex applications that tackle real business problems.

A good example of a Pig application is the ETL transaction model that describes how a process will extract data from a source, transform it according to a rule set, and then load it into a datastore. Pig can ingest data from files, streams or other sources using the User Defined Functions (UDF). Once it has the data it can perform select, iteration, and other transforms over the data. Again the UDF feature allows passing the data to more complex algorithms for the transform. Finally Pig can store the results into the Hadoop Data File System.

Pig scripts are translated into a series of MapReduce jobs that are run on the Apache Hadoop cluster. As part of the translation the Pig interpreter does perform optimizations to speed execution on Apache Hadoop. We are going to write a Pig script that will do our data analysis task.

## What is Tez?

Tez – Hindi for “speed” provides a general-purpose, highly customizable framework that creates simplifies data-processing tasks across both small scale (low-latency) and large-scale (high throughput) workloads in Hadoop. It generalizes the MapReduce paradigm to a more powerful framework by providing the ability to execute a complex DAG (directed acyclic graph) of tasks for a single job so that projects in the Apache Hadoop ecosystem such as Apache Hive, Apache Pig and Cascading can meet requirements for human-interactive response times and extreme throughput at petabyte scale (clearly MapReduce has been a key driver in achieving this).

## Pig Execution Modes

When you run the `pig` command line interface, you are placed in the Grunt shell where you can write Pig Latin scripts. There are three execution modes of the Grunt shell:

* local – Type `pig -x local` to enter the shell
* mapreduce – Type `pig -x mapreduce` to enter the shell
* tez – Type `pig -x tez` to enter the shell

The default is mapreduce, so if you just type `pig`, it will use mapreduce as the execution mode. Explore [this link](https://pig.apache.org/docs/r0.16.0/cmds.html) to explore more about the grunt shell.

## Our Data Processing Task

We are going to read in truck driver statistics files. We are going to compute the sum of hours and miles logged driven by a truck driver for a year. Once we have the sum of hours and miles logged, we will extend the script to translate a driver id field into the name of the drivers by joining two different files.


## Instructions

1. To start, copy the data files `truck_drivers.csv` and `timesheet.csv` to HDFS.

    If you are running in the Hortonworks VM:

    ```
    [hdfs@sandbox ~]$ hadoop fs -put /tmp/drivers.csv /tmp/drivers.csv
    [hdfs@sandbox ~]$ hadoop fs -put /tmp/timesheet.csv /tmp/timesheet.csv
    ```

1. Start the `pig` command line client with no arguments so that we are in mapreduce mode.

    ```
    [hdfs@sandbox ~]$ pig
    ```

1. The first thing we need to do is load the data. We use the `LOAD` statement for this. The PigStorage function is what does the loading and we pass it a comma as the data delimiter. Enter this line in the pig session:

    ```pig
    drivers = LOAD '/user/<user>/truck_drivers.csv' USING PigStorage(',');
    ```

1. To filter out the first row of data (the CSV headers) we have to add this line:

    ```pig
    raw_drivers = FILTER drivers BY $0>1;
    ```

1. The next thing we want to do is name the fields. We will use a `FOREACH` statement to iterate through the `raw_drivers` data object. Then `GENERATE` pulls out selected fields and assigns them names. The new data object we are creating is then named `driver_details`. Enter this line:

    ```pig
    drivers_details = FOREACH raw_drivers GENERATE $0 AS driverId, $1 AS name;
    ```

1. Load the `timesheet` data and filter out the first row of data to remove column headings. Then use a `FOREACH` statement to iterate each row and `GENERATE` to pull out selected fields and assign them names. Enter these lines:

    ```pig
    timesheet = LOAD '/user/<user>/timesheet.csv' USING PigStorage(',');
    raw_timesheet = FILTER timesheet by $0>1;
    timesheet_logged = FOREACH raw_timesheet GENERATE $0 AS driverId, $2 AS hours_logged, $3 AS miles_logged;
    ```

1. The next line of code is a `GROUP` statement that groups the elements in `timesheet_logged` by the `driverId` field. The `grp_logged` object will then be indexed by `driverId`. In the next statement as we iterate through `grp_logged` we will go through driverId by driverId. Type in the code:

    ```pig
    grp_logged = GROUP timesheet_logged by driverId;
    ```

1. In the next `FOREACH` statement, we are going to find the sum of hours and miles logged by each driver. The code for this is:

    ```pig
    sum_logged = FOREACH grp_logged GENERATE group as driverId,
    SUM(timesheet_logged.hours_logged) as sum_hourslogged,
    SUM(timesheet_logged.miles_logged) as sum_mileslogged;
    ```

1. Now that we have the sum of hours and miles logged, we need to join this with the `driver_details` data object so we can pick up the name of the driver. The result will be a dataset with `driverId`, `name`, `hours_logged`, and `miles_logged`. At the end we `DUMP` the data to the output.

    ```pig
    join_sum_logged = JOIN sum_logged by driverId, drivers_details by driverId;
    join_data = FOREACH join_sum_logged GENERATE $0 as driverId, $4 as name, $1 as hours_logged, $2 as miles_logged;
    dump join_data;
    ```

1. Let’s take a look at our complete script.

    ```pig
    drivers = LOAD '/user/<user>/drivers.csv' USING PigStorage(',');
    raw_drivers = FILTER drivers BY $0>1;
    drivers_details = FOREACH raw_drivers GENERATE $0 AS driverId, $1 AS name;
    timesheet = LOAD '/user/<user>/timesheet.csv' USING PigStorage(',');
    raw_timesheet = FILTER timesheet by $0>1;
    timesheet_logged = FOREACH raw_timesheet GENERATE $0 AS driverId, $2 AS hours_logged, $3 AS miles_logged;
    grp_logged = GROUP timesheet_logged by driverId;
    sum_logged = FOREACH grp_logged GENERATE group as driverId,
    SUM(timesheet_logged.hours_logged) as sum_hourslogged,
    SUM(timesheet_logged.miles_logged) as sum_mileslogged;
    join_sum_logged = JOIN sum_logged by driverId, drivers_details by driverId;
    join_data = FOREACH join_sum_logged GENERATE $0 as driverId, $4 as name, $1 as hours_logged, $2 as miles_logged;
    dump join_data;
    ```

    The first thing to notice is we never really address single rows of data to the left of the equals sign and on the right we just describe what we want to do for each row. We just assume things are applied to all the rows. We also have powerful operators like `GROUP` and `JOIN` to sort rows by a key and to build new data objects.

    When you execute this script, the output should look like the following:

    ```
    (10,George Vetticaden,3232.0,147150.0)
    (11,Jamie Engesser,3642.0,179300.0)
    (12,Paul Coddin,2639.0,135962.0)
    (13,Joe Niemiec,2727.0,134126.0)
    (14,Adis Cesir,2781.0,136624.0)
    (15,Rohit Bakshi,2734.0,138750.0)
    (16,Tom McCuch,2746.0,137205.0)
    (17,Eric Mizell,2701.0,135992.0)
    (18,Grant Liu,2654.0,137834.0)
    (19,Ajay Singh,2738.0,137968.0)
    (20,Chris Harris,2644.0,134564.0)
    (21,Jeff Markham,2751.0,138719.0)
    (22,Nadeem Asghar,2733.0,137550.0)
    (23,Adam Diaz,2750.0,137980.0)
    (24,Don Hilborn,2647.0,134461.0)
    (25,Jean-Philippe Playe,2723.0,139180.0)
    (26,Michael Aube,2730.0,137530.0)
    (27,Mark Lochbihler,2771.0,137922.0)
    (28,Olivier Renault,2723.0,137469.0)
    (29,Teddy Choi,2760.0,138255.0)
    (30,Dan Rice,2773.0,137473.0)
    (31,Rommel Garcia,2704.0,137057.0)
    (32,Ryan Templeton,2736.0,137422.0)
    (33,Sridhara Sabbella,2759.0,139285.0)
    (34,Frank Romano,2811.0,137728.0)
    (35,Emil Siemes,2728.0,138727.0)
    (36,Andrew Grande,2795.0,138025.0)
    (37,Wes Floyd,2694.0,137223.0)
    (38,Scott Shaw,2760.0,137464.0)
    (39,David Kaiser,2745.0,138788.0)
    (40,Nicolas Maillard,2700.0,136931.0)
    (41,Greg Phillips,2723.0,138407.0)
    (42,Randy Gelhausen,2697.0,136673.0)
    (43,Dave Patton,2750.0,136993.0)
    ```

1. Now exit the grunt shell and re-start pig with the Tez option:

    ```
    [hdfs@sandbox ~]$ pig -x tez
    ```

    Run the same script again and take note of the difference in execution speed. It will vary depending on your Hadoop cluster but you should see a speed performance even without any specific optimization in the script for Tez.

1. Now exit the grunt shell and re-start pig with the local option:

    ```
    [hdfs@sandbox ~]$ pig -x local
    ```

    When you run Pig in the local mode, Pig accesses the files on the local file system.

    Run the script again, but change the location of the files, so they match their local on the Hadoop server (not HDFS!).

    You should see script executing in a fraction of the time! Local mode is convenient for initial development, before you start processing large files in HDFS.    

## Recap

We have created a simple Pig script that reads in some comma separated data. Once we have that set of records in Pig we pull out the `driverId`, hours logged and miles logged fields from each row. We then group them by `driverId` with one statement, `GROUP`. Then we find the sum of hours and miles logged for each `driverId`. This is finally mapped to the driver name by joining two datasets and we produce our final dataset.

As mentioned before Pig operates on data flows. We consider each group of rows together and we specify how we operate on them as a group. As the datasets get larger and/or add fields our Pig script will remain pretty much the same because it is concentrating on how we want to manipulate the data.
