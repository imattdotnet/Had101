# User Defined Functions in Java

In this lab, you will perform some analysis of search engine results from [Excite](http://www.excite.com/). (This is the dataset that comes with Apache Pig examples.) The Pig script will make use of several User Defined Functions (UDFs) in Java. The UDFs can be found under the `src` directory and cover the following functionality:

| UDF | Description |
| --- | ----------- |
| ExtractHour | Extracts the hour from the record. |
| NGramGenerator | Composes n-grams from the set of words. |
| NonURLDetector | Removes the record if the query field is empty or a URL. |
| ScoreGenerator | Calculates a "popularity" score for the n-gram. |
| ToLower | Changes the query field to lowercase. |
| TutorialUtil | Divides the query string into a set of words. |

Take some time to open the source files in a text editor to see how these functions are constructed.

## Instructions

First, copy the data file onto the local filesystem of the host from which you are running Pig into an area where you can add it to HDFS:

In PayPal, copy the file from local, to bastion, to Hadoop server.

If you are running this in a Hortonworks Sandbox VM:
```
[root@sandbox ~]# sudo -u hdfs hadoop fs -put /tmp/excite.log.bz2 /tmp/excite.log.bz2
```

Next, copy the `src` directory to your Pig host so that the Java code can be compiled.

At PayPal, you can use `scp -r ...` command and recursively copy the whole directory.

When you are done, `cd` into the directory.

The directions for compiling the code will be different depending on your Pig version and Hadoop environment. In general, the `javac` classpath argument must include the Pig library as well as Hadoop libraries.

In PayPal:
```
javac -cp $(hadoop classpath):/usr/hdp/current/pig-client/pig-0.16.0.2.5.3.0-37-core-h2.jar org/apache/pig/tutorial/*
jar -cf tutorial.jar org/
```

If you are Using Hortonworks Sandbox, you can compile and package the code as follows (the versions of the libraries are slightly different from Hadoop cluster at PayPal):

```
[root@sandbox src]# javac -cp $(hadoop classpath):/usr/hdp/current/pig-client/pig-0.16.0.2.5.0.0-1245-core-h2.jar org/apache/pig/tutorial/*
[root@sandbox src]# jar -cf tutorial.jar org/
```

When you run the `pig` command line client, make sure that the `tutorial.jar` is in the current directory or adjust the location in the script below as needed.

### Query Phrase Popularity

The `query-phrase-popularity.pig` script processes a search query log file from the Excite search engine and finds search phrases that occur with particular high frequency during certain times of the day.

Run the `pig` client and follow along with each step. For file names, remember to change `<user>` with your user name.

* Register the tutorial JAR file so that the included UDFs can be called in the script.

```pig
REGISTER ./tutorial.jar;
```

* Use the PigStorage function to load the excite log file into the `raw` bag as an array of records with the fields user, time, and query.

```pig
raw = LOAD '/user/<user>/excite.log.bz2' USING PigStorage('\t') AS (user, time, query);
```

* Call the NonURLDetector UDF to remove records if the query field is empty or a URL.

```pig
clean1 = FILTER raw BY org.apache.pig.tutorial.NonURLDetector(query);
```

* Call the ToLower UDF to change the query field to lowercase.

```pig
clean2 = FOREACH clean1 GENERATE user, time, org.apache.pig.tutorial.ToLower(query) as query;
```

* Because the log file only contains queries for a single day, we are only interested in the hour. The Excite query log timestamp format is YYMMDDHHMMSS. Call the ExtractHour UDF to extract the hour (HH) from the time field.

```pig
houred = FOREACH clean2 GENERATE user, org.apache.pig.tutorial.ExtractHour(time) as hour, query;
```

* Call the NGramGenerator UDF to compose the n-grams of the query.

```pig
ngramed1 = FOREACH houred GENERATE user, hour, flatten(org.apache.pig.tutorial.NGramGenerator(query)) as ngram;
```

* Use the DISTINCT operator to get the unique n-grams for all records.

```pig
ngramed2 = DISTINCT ngramed1;
```

* Use the GROUP operator to group records by n-gram and hour.

```pig
hour_frequency1 = GROUP ngramed2 BY (ngram, hour);
```

* Use the COUNT function to get the count (occurrences) of each n-gram.

```pig
hour_frequency2 = FOREACH hour_frequency1 GENERATE flatten($0), COUNT($1) as count;
```

* Use the GROUP operator to group records by n-gram only. Each group now corresponds to a distinct n-gram and has the count for each hour.

```pig
uniq_frequency1 = GROUP hour_frequency2 BY group::ngram;
```

* For each group, identify the hour in which this n-gram is used with a particularly high frequency. Call the ScoreGenerator UDF to calculate a "popularity" score for the n-gram.

```pig
uniq_frequency2 = FOREACH uniq_frequency1 GENERATE flatten($0), flatten(org.apache.pig.tutorial.ScoreGenerator($1));
```

* Use the FOREACH-GENERATE operator to assign names to the fields.

```pig
uniq_frequency3 = FOREACH uniq_frequency2 GENERATE $1 as hour, $0 as ngram, $2 as score, $3 as count, $4 as mean;
```

* Use the FILTER operator to remove all records with a score less than or equal to 2.0.

```pig
filtered_uniq_frequency = FILTER uniq_frequency3 BY score > 2.0;
```

* Use the ORDER operator to sort the remaining records by hour and score.

```pig
ordered_uniq_frequency = ORDER filtered_uniq_frequency BY hour, score;
```

* Finally, you can view the results which contains a list of n-grams with the following fields: hour, ngram, score, count, mean.

```pig
DUMP ordered_uniq_frequency;
```

* If you want to store results into a file on HDFS, you can use the PigStorage function

```pig
STORE ordered_uniq_frequency INTO '/user/<user>/query-phrase-results' USING PigStorage();
```

### Temporal Query Phrase Popularity

The `temporal-query-phrase-popularity.pig` script processes a search query log file from the Excite search engine and compares the occurrence of frequency of search phrases across two time periods separated by twelve hours.

Run the `pig` client and follow along with each step:

* Register the tutorial JAR file so that the included UDFs can be called in the script.

```pig
REGISTER ./tutorial.jar;
```

* Use the PigStorage function to load the Excite log file into the `raw` bag as an array of records with the fields user, time, and query.

```pig
raw = LOAD '/user/<user>/excite.log.bz2' USING PigStorage('\t') AS (user, time, query);
```

* Call the NonURLDetector UDF to remove records if the query field is empty or a URL.

```
clean1 = FILTER raw BY org.apache.pig.tutorial.NonURLDetector(query);
```

* Call the ToLower UDF to change the query field to lowercase.

```pig
clean2 = FOREACH clean1 GENERATE user, time, org.apache.pig.tutorial.ToLower(query) as query;
```

* Because the log file only contains queries for a single day, we are only interested in the hour. The excite query log timestamp format is YYMMDDHHMMSS. Call the ExtractHour UDF to extract the hour from the time field.

```pig
houred = FOREACH clean2 GENERATE user, org.apache.pig.tutorial.ExtractHour(time) as hour, query;
```

* Call the NGramGenerator UDF to compose the n-grams of the query.

```pig
ngramed1 = FOREACH houred GENERATE user, hour, flatten(org.apache.pig.tutorial.NGramGenerator(query)) as ngram;
```

* Use the DISTINCT operator to get the unique n-grams for all records.

```pig
ngramed2 = DISTINCT ngramed1;
```

* Use the GROUP operator to group the records by n-gram and hour.

```pig
hour_frequency1 = GROUP ngramed2 BY (ngram, hour);
```

* Use the COUNT function to get the count (occurrences) of each n-gram.

```pig
hour_frequency2 = FOREACH hour_frequency1 GENERATE flatten($0), COUNT($1) as count;
```

* Use the FOREACH-GENERATE operator to assign names to the fields.

```pig
hour_frequency3 = FOREACH hour_frequency2 GENERATE $0 as ngram, $1 as hour, $2 as count;
```

* Use the FILTER operator to get the n-grams for hour ‘00’

```pig
hour00 = FILTER hour_frequency2 BY hour eq '00';
```

* Use the FILTER operators to get the n-grams for hour ‘12’

```pig
hour12 = FILTER hour_frequency3 BY hour eq '12';
```

* Use the JOIN operator to get the n-grams that appear in both hours.

```pig
same = JOIN hour00 BY $0, hour12 BY $0;
```

* Use the FOREACH-GENERATE operator to record their frequency.

```pig
same1 = FOREACH same GENERATE hour00::group::ngram as ngram, $2 as count00, $5 as count12;
```

* Finally, you can view the results which contains a list of n-grams with the following fields: ngram, count00, count12.

```pig
DUMP same1;
```

* If you want to store results into a file on HDFS, you can use the PigStorage function

```pig
STORE same1 INTO '/user/<user>/temporal-query-phrase-popularity' USING PigStorage();
```
